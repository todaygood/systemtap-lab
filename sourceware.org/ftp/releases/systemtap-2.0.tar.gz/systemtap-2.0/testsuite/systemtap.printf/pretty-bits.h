struct pretty_bits {
    signed char a:4, b:4;
    unsigned char c:4, d:4;
    signed int e:4, f:4;
    unsigned int g:4, h:4;
};
