static int counter;

void
foo(void)
{
  counter = 7;
}

void
bar(void)
{
  counter++;
}
