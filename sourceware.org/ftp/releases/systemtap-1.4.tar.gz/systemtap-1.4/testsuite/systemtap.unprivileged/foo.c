/* Test application */
void bar () {
}

main () {
  bar ();
}
