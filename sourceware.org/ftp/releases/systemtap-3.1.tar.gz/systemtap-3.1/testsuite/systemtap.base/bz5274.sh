#! /bin/bash
./bz5274 > ./bz5274.out
