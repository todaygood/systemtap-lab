void add_to_cache(systemtap_session& s);
bool get_from_cache(systemtap_session& s);
